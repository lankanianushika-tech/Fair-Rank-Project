from typing import Dict
from .candidate import Candidate
from .job_description import JobDescription
from .feature_extractor import FeatureExtractor

class CandidateScorer:
    """
    Computes a candidate's fit score against a JobDescription using a 5-component weighted scoring function:
      1. Required Skills Match (Default Weight 0.50)
      2. Preferred Skills Match (Default Weight 0.20)
      3. Experience Match (Default Weight 0.15)
      4. Education Level Match (Default Weight 0.10)
      5. Certifications Match (Default Weight 0.05)
    
    Time Complexity: O(1) per candidate evaluation given pre-extracted sets.
    """

    EDU_RANKS = {
        "High School": 1,
        "Associate": 2,
        "Bachelor": 3,
        "Master": 4,
        "Doctorate": 5,
        "Unknown": 1,
    }

    @classmethod
    def score(cls, candidate: Candidate, job: JobDescription) -> Dict[str, float]:
        w = job.weights

        # 1. Required Skills Score
        if job.required_skills:
            req_matched = candidate.skills & job.required_skills
            req_score = len(req_matched) / len(job.required_skills)
        else:
            req_score = 1.0

        # 2. Preferred Skills Score
        if job.preferred_skills:
            pref_matched = candidate.skills & job.preferred_skills
            pref_score = len(pref_matched) / len(job.preferred_skills)
        else:
            pref_score = 1.0

        # 3. Experience Score (bounded ratio up to 1.0)
        if job.min_experience_years > 0:
            exp_score = min(1.0, candidate.experience_years / job.min_experience_years)
        else:
            exp_score = 1.0

        # 4. Education Score
        cand_edu_rank = cls.EDU_RANKS.get(candidate.education_level, 1)
        req_edu_rank = cls.EDU_RANKS.get(job.required_education, 3)
        if cand_edu_rank >= req_edu_rank:
            edu_score = 1.0
        else:
            edu_score = max(0.0, cand_edu_rank / req_edu_rank)

        # 5. Certifications Score
        if job.required_certifications:
            cert_matched = candidate.certifications & job.required_certifications
            cert_score = len(cert_matched) / len(job.required_certifications)
        else:
            cert_score = 1.0

        total_score = (
            w["required_skills"] * req_score +
            w["preferred_skills"] * pref_score +
            w["experience"] * exp_score +
            w["education"] * edu_score +
            w["certifications"] * cert_score
        )

        breakdown = {
            "required_skills": req_score,
            "preferred_skills": pref_score,
            "experience": exp_score,
            "education": edu_score,
            "certifications": cert_score,
            "total": total_score,
        }

        candidate.score_breakdown = breakdown
        return breakdown
