import re

class ResumeAnonymizer:
    """
    Masks Personally Identifiable Information (PII) such as full names, email addresses,
    phone numbers, dates of birth, and URLs from resume text before scoring.
    """

    EMAIL_PATTERN = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b')
    PHONE_PATTERN = re.compile(r'(\+?\d{1,4}[-.\s]?)?(\(?\d{2,4}\)?[-.\s]?)?\d{3,4}[-.\s]?\d{3,4}\b')
    URL_PATTERN = re.compile(r'https?://\S+|www\.\S+')
    DOB_PATTERN = re.compile(r'\b(dob|date of birth|born)[:\s]*\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b', re.IGNORECASE)

    @classmethod
    def mask(cls, text: str, name: str = "") -> str:
        """
        Masks PII patterns in the provided text. If an explicit candidate name is passed,
        occurrences of that name are replaced with [NAME].
        """
        if not text:
            return ""

        masked = text
        masked = cls.EMAIL_PATTERN.sub("[EMAIL]", masked)
        masked = cls.PHONE_PATTERN.sub("[PHONE]", masked)
        masked = cls.URL_PATTERN.sub("[URL]", masked)
        masked = cls.DOB_PATTERN.sub("[DOB]", masked)

        if name and name.strip():
            # Escape regex special characters in name and match case-insensitively
            name_parts = [re.escape(part) for part in name.strip().split() if len(part) > 1]
            if name_parts:
                pattern = re.compile(r'\b(' + '|'.join(name_parts) + r')\b', re.IGNORECASE)
                masked = pattern.sub("[NAME]", masked)

        return masked
