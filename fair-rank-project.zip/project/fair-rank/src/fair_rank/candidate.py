from typing import Set, Dict, Optional

class Candidate:
    """
    Data model representing an anonymized candidate profile.
    Original text is stored separately and never exposed to scoring to preserve fairness.
    """

    def __init__(
        self,
        candidate_id: str,
        masked_text: str,
        original_text: str = "",
        skills: Optional[Set[str]] = None,
        experience_years: float = 0.0,
        education_level: str = "Unknown",
        certifications: Optional[Set[str]] = None,
        score_breakdown: Optional[Dict[str, float]] = None,
        explanation: Optional[str] = None,
    ):
        self.candidate_id = candidate_id
        self.masked_text = masked_text
        self.original_text = original_text
        self.skills = skills if skills is not None else set()
        self.experience_years = float(experience_years)
        self.education_level = education_level
        self.certifications = certifications if certifications is not None else set()
        self.score_breakdown = score_breakdown
        self.explanation = explanation

    @property
    def total_score(self) -> float:
        if self.score_breakdown and "total" in self.score_breakdown:
            return self.score_breakdown["total"]
        return 0.0

    def __repr__(self) -> str:
        return f"<Candidate id='{self.candidate_id}' skills={len(self.skills)} exp={self.experience_years}y score={self.total_score:.2f}>"
