from typing import Set, Dict, Optional

class JobDescription:
    """
    Data model representing a job posting requirement specification.
    Validates that candidate scoring component weights sum strictly to 1.0.
    """

    DEFAULT_WEIGHTS = {
        "required_skills": 0.50,
        "preferred_skills": 0.20,
        "experience": 0.15,
        "education": 0.10,
        "certifications": 0.05,
    }

    def __init__(
        self,
        title: str,
        required_skills: Set[str],
        preferred_skills: Optional[Set[str]] = None,
        min_experience_years: float = 0.0,
        required_education: str = "Bachelor",
        required_certifications: Optional[Set[str]] = None,
        k: int = 10,
        weights: Optional[Dict[str, float]] = None,
        job_id: str = "JOB_001",
    ):
        self.job_id = job_id
        self.title = title
        self.required_skills = {s.lower().strip() for s in required_skills}
        self.preferred_skills = {s.lower().strip() for s in (preferred_skills or set())}
        self.min_experience_years = float(min_experience_years)
        self.required_education = required_education.strip()
        self.required_certifications = {c.lower().strip() for c in (required_certifications or set())}
        self.k = int(k)
        
        self.weights = weights if weights is not None else dict(self.DEFAULT_WEIGHTS)
        self._validate_weights()

    def _validate_weights(self) -> None:
        total = sum(self.weights.values())
        if abs(total - 1.0) > 1e-5:
            raise ValueError(f"JobDescription weights must sum to 1.0, got {total:.4f}")

    def __repr__(self) -> str:
        return f"<JobDescription title='{self.title}' required_skills={len(self.required_skills)} k={self.k}>"
