from typing import Dict
from .candidate import Candidate
from .job_description import JobDescription

class ExplanationGenerator:
    """
    Generates deterministic, audit-friendly, human-readable explanations summarizing
    why a candidate received a given score breakdown for a job posting.
    """

    @classmethod
    def generate(cls, candidate: Candidate, job: JobDescription, breakdown: Dict[str, float]) -> str:
        total = breakdown.get("total", 0.0) * 100.0
        req_pct = breakdown.get("required_skills", 0.0) * 100.0
        pref_pct = breakdown.get("preferred_skills", 0.0) * 100.0

        matched_req = candidate.skills & job.required_skills
        missing_req = job.required_skills - candidate.skills
        
        matched_pref = candidate.skills & job.preferred_skills

        explanation_parts = [
            f"Overall Match Score: {total:.1f}%.",
            f"Required Skills ({req_pct:.0f}% match): Matched [{', '.join(sorted(matched_req)) or 'None'}]."
        ]

        if missing_req:
            explanation_parts.append(f"Missing required skills: [{', '.join(sorted(missing_req))}].")
        
        if matched_pref:
            explanation_parts.append(f"Preferred Skills ({pref_pct:.0f}% match): Matched [{', '.join(sorted(matched_pref))}].")

        explanation_parts.append(
            f"Experience: {candidate.experience_years} years (Required: {job.min_experience_years} yrs)."
        )
        explanation_parts.append(
            f"Education: {candidate.education_level} (Required: {job.required_education})."
        )

        full_exp = " ".join(explanation_parts)
        candidate.explanation = full_exp
        return full_exp
