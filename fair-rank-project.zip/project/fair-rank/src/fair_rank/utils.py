import time
import tracemalloc
from typing import Callable, Any, Tuple

class Timer:
    """High-precision execution wall-clock timer using time.perf_counter()."""

    def __enter__(self):
        self.start = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.end = time.perf_counter()
        self.interval = self.end - self.start

def measure_execution(func: Callable, *args, **kwargs) -> Tuple[Any, float, float]:
    """
    Executes func(*args, **kwargs) and measures wall-clock time (seconds)
    and peak memory allocation (MB).
    """
    tracemalloc.start()
    start_time = time.perf_counter()
    
    result = func(*args, **kwargs)
    
    elapsed_time = time.perf_counter() - start_time
    _, peak_bytes = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    
    peak_mb = peak_bytes / (1024 * 1024)
    return result, elapsed_time, peak_mb
