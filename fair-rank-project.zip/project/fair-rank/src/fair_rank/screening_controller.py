import json
from typing import List, Dict, Tuple, Any, Optional
from .job_description import JobDescription
from .candidate import Candidate
from .anonymizer import ResumeAnonymizer
from .normalizer import TextNormalizer
from .skill_trie import SkillTrie
from .skill_graph import SkillGraph
from .feature_extractor import FeatureExtractor
from .inverted_index import InvertedIndex
from .scorer import CandidateScorer
from .top_k_ranker import TopKRanker
from .fairness_auditor import FairnessAuditor
from .explanation_generator import ExplanationGenerator

class ScreeningController:
    """
    Orchestrates the complete 10-stage FAIR-RANK recruitment pipeline:
      Stage 1: Build SkillTrie from controlled dictionary
      Stage 2: Load SkillGraph from synonym adjacency list
      Stage 3: Instantiate InvertedIndex
      Stage 4: Mask candidate PII (ResumeAnonymizer)
      Stage 5: Normalize resume text (TextNormalizer)
      Stage 6: Extract & resolve skills/features (SkillTrie, SkillGraph, FeatureExtractor)
      Stage 7: Populate InvertedIndex with processed candidates
      Stage 8: Sub-linear candidate retrieval via InvertedIndex
      Stage 9: Score candidates and push to TopKRanker min-heap with generated explanations
      Stage 10: Run FairnessAuditor suite and return ranked shortlist + audit report
    """

    def __init__(
        self,
        skills_dict_path: str = "data/skills_dictionary.json",
        synonyms_path: str = "data/skills_synonyms.json"
    ):
        # Stage 1: SkillTrie
        self.trie = SkillTrie()
        with open(skills_dict_path, 'r', encoding='utf-8') as f:
            skills_data = json.load(f)
            self.trie.build(skills_data.get("skills", []))

        # Stage 2: SkillGraph
        self.graph = SkillGraph(synonyms_path)

        # Stage 3: InvertedIndex
        self.index = InvertedIndex()
        
        self.candidates_dict: Dict[str, Candidate] = {}

    def process_and_index_resumes(self, raw_resumes: List[Dict[str, Any]]) -> List[Candidate]:
        """
        Executes Stages 4 through 7 over a batch of raw candidate resume dictionaries.
        """
        processed_candidates = []
        for raw in raw_resumes:
            cand_id = raw.get("candidate_id", f"C_{len(processed_candidates)+1:03d}")
            raw_text = raw.get("resume_text", "")
            name = raw.get("full_name", "")

            # Stage 4: Mask PII
            masked = ResumeAnonymizer.mask(raw_text, name=name)

            # Stage 5: Normalize text
            norm = TextNormalizer.normalize(masked)

            # Stage 6: Extract & resolve skills and features
            extracted_skills = self.trie.extract(norm)
            resolved_skills = self.graph.resolve_synonyms(extracted_skills)
            exp, edu, certs = FeatureExtractor.extract(norm)

            # Fallback to explicit CSV values if available and non-zero
            if raw.get("experience_years"):
                try:
                    exp = max(exp, float(raw["experience_years"]))
                except ValueError:
                    pass
            if raw.get("education_level") and raw["education_level"] != "Unknown":
                edu = raw["education_level"]

            cand = Candidate(
                candidate_id=cand_id,
                masked_text=masked,
                original_text=raw_text,
                skills=resolved_skills,
                experience_years=exp,
                education_level=edu,
                certifications=certs,
            )

            # Stage 7: Add to InvertedIndex
            self.index.add(cand)
            self.candidates_dict[cand_id] = cand
            processed_candidates.append(cand)

        return processed_candidates

    def run_screening(
        self,
        job: JobDescription,
        raw_resumes: Optional[List[Dict[str, Any]]] = None
    ) -> Tuple[List[Candidate], List[Dict[str, Any]]]:
        """
        Executes Stages 8 through 10 of the pipeline to produce a Top-K shortlist and fairness audit.
        """
        if raw_resumes:
            self.process_and_index_resumes(raw_resumes)

        # Stage 8: Sub-linear Candidate Retrieval
        relevant_ids = self.index.retrieve(job.required_skills, job.preferred_skills)
        pool = [self.candidates_dict[cid] for cid in relevant_ids if cid in self.candidates_dict]
        if not pool:
            pool = list(self.candidates_dict.values())

        # Stage 9: Candidate Scoring & Top-K Min-Heap Ranking
        ranker = TopKRanker(job.k)
        for cand in pool:
            breakdown = CandidateScorer.score(cand, job)
            cand.explanation = ExplanationGenerator.generate(cand, job, breakdown)
            ranker.push(cand, breakdown["total"])

        shortlist = ranker.get_ranked()

        # Stage 10: Fairness Audit
        auditor = FairnessAuditor(self.trie, self.graph)
        sample_resume_text = pool[0].original_text if pool else "Software Engineer with Python and SQL experience."
        audit_report = auditor.run_default_suite(job, sample_resume_text)

        return shortlist, audit_report
