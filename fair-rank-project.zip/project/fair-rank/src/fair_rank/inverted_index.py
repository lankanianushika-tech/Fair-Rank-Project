from typing import Dict, Set, Iterable
from .candidate import Candidate

class InvertedIndex:
    """
    Inverted Index data structure mapping skill terms to candidate IDs (dict[str, set[str]]).
    Enables sub-linear candidate retrieval so only candidates possessing relevant required/preferred
    skills are evaluated during scoring.
    """

    def __init__(self):
        self.index: Dict[str, Set[str]] = {}
        self.total_candidates = 0

    def add(self, candidate: Candidate) -> None:
        """
        Indexes a candidate under each of their extracted skills.
        Time Complexity: O(s) per candidate where s is candidate skill count.
        """
        for skill in candidate.skills:
            norm_skill = skill.lower().strip()
            if norm_skill not in self.index:
                self.index[norm_skill] = set()
            self.index[norm_skill].add(candidate.candidate_id)
        self.total_candidates += 1

    def retrieve(self, required_skills: Iterable[str], preferred_skills: Iterable[str] = ()) -> Set[str]:
        """
        Retrieves candidate IDs possessing at least one required or preferred skill.
        If no skills are specified, returns empty set.
        Time Complexity: O(r * avg posting length) where r is total required + preferred skills.
        """
        relevant_candidates: Set[str] = set()
        all_query_skills = set(required_skills) | set(preferred_skills)

        for skill in all_query_skills:
            norm_skill = skill.lower().strip()
            if norm_skill in self.index:
                relevant_candidates.update(self.index[norm_skill])

        return relevant_candidates
