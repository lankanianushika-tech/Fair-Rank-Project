import re
from typing import List

class TextNormalizer:
    """
    Handles lowercasing, punctuation stripping, unicode cleaning, and tokenization.
    """

    PUNCTUATION_PATTERN = re.compile(r'[^\w\s\+\#\/\.\-]')

    @classmethod
    def normalize(cls, text: str) -> str:
        """
        Converts text to lowercase, removes sentence punctuation, and cleans whitespace.
        Preserves special tech terms like C++, C#, .NET, Node.js, CI/CD.
        """
        if not text:
            return ""

        lowercased = text.lower()
        # Remove dots that are at word boundaries / sentence ends (e.g. "science.")
        cleaned = re.sub(r'(?<=\w)\.(?=\s|$)', ' ', lowercased)
        cleaned = cls.PUNCTUATION_PATTERN.sub(' ', cleaned)
        cleaned = re.sub(r'\s+', ' ', cleaned).strip()
        return cleaned

    @classmethod
    def tokenize(cls, text: str) -> List[str]:
        """
        Splits normalized text into word tokens.
        """
        norm = cls.normalize(text)
        return norm.split() if norm else []
