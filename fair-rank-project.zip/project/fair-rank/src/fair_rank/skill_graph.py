import json
from typing import Dict, Set, List, Union

class SkillGraph:
    """
    Skill Synonym Graph implemented as an adjacency list dictionary (dict[str, set[str]]).
    Resolves skill variants and acronyms (e.g. "py" -> "python", "k8s" -> "kubernetes")
    to canonical terms using strict 1-hop direct mapping to preserve auditable transparency.
    """

    def __init__(self, synonym_dict_or_path: Union[Dict[str, List[str]], str]):
        self.adj_list: Dict[str, Set[str]] = {}
        if isinstance(synonym_dict_or_path, str):
            self.load_from_json(synonym_dict_or_path)
        else:
            self._build_from_dict(synonym_dict_or_path)

    def _build_from_dict(self, data: Dict[str, List[str]]) -> None:
        for term, canonical_terms in data.items():
            norm_term = term.lower().strip()
            norm_canonicals = {c.lower().strip() for c in canonical_terms}
            self.adj_list[norm_term] = norm_canonicals

    def load_from_json(self, path: str) -> None:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        self._build_from_dict(data)

    def resolve_synonyms(self, skills: Set[str]) -> Set[str]:
        """
        Resolves a set of extracted skills to include direct 1-hop canonical equivalents.
        Does NOT perform multi-hop BFS/DFS traversal to prevent semantic drift.
        Time Complexity: O(1) average lookup per skill, O(s) for candidate skill set size s.
        """
        resolved: Set[str] = set()
        for skill in skills:
            norm_skill = skill.lower().strip()
            resolved.add(norm_skill)
            if norm_skill in self.adj_list:
                resolved.update(self.adj_list[norm_skill])
        return resolved
