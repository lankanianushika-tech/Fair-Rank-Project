from typing import List, Dict, Tuple, Any
from .candidate import Candidate
from .job_description import JobDescription
from .anonymizer import ResumeAnonymizer
from .normalizer import TextNormalizer
from .skill_trie import SkillTrie
from .skill_graph import SkillGraph
from .feature_extractor import FeatureExtractor
from .scorer import CandidateScorer

class FairnessAuditor:
    """
    Evaluates algorithmic bias by generating counterfactual resume pairs that differ ONLY by
    a single protected attribute or identity proxy (name, pronoun, email format, text padding),
    running both through the complete pipeline, and recording score and rank differentials.
    """

    DEFAULT_COUNTERFACTUAL_PAIRS = [
        {"test_type": "Name Bias (Male vs Female)", "field": "name", "val_a": "John Smith", "val_b": "Mary Smith"},
        {"test_type": "Name Bias (Western vs Non-Western)", "field": "name", "val_a": "David Miller", "val_b": "Tariq Al-Mansoor"},
        {"test_type": "Pronoun Bias", "field": "pronoun", "val_a": "He", "val_b": "She"},
        {"test_type": "Email Domain Proxy Bias", "field": "email", "val_a": "john.smith@gmail.com", "val_b": "john.smith@hbcu.edu"},
        {"test_type": "Formatting Whitespace Padding", "field": "text_padding", "val_a": "Software Engineer with Python experience", "val_b": "Software Engineer   with   Python   experience  "},
    ]

    def __init__(self, trie: SkillTrie, graph: SkillGraph):
        self.trie = trie
        self.graph = graph

    def process_raw_text(self, candidate_id: str, raw_text: str, candidate_name: str = "") -> Candidate:
        """
        Passes a single raw resume text through anonymization, normalization, skill extraction,
        synonym resolution, and feature extraction to return a Candidate object.
        """
        masked = ResumeAnonymizer.mask(raw_text, name=candidate_name)
        norm = TextNormalizer.normalize(masked)
        extracted_skills = self.trie.extract(norm)
        resolved_skills = self.graph.resolve_synonyms(extracted_skills)
        exp, edu, certs = FeatureExtractor.extract(norm)

        return Candidate(
            candidate_id=candidate_id,
            masked_text=masked,
            original_text=raw_text,
            skills=resolved_skills,
            experience_years=exp,
            education_level=edu,
            certifications=certs,
        )

    def audit_pair(
        self,
        job: JobDescription,
        test_type: str,
        cand_a: Candidate,
        cand_b: Candidate
    ) -> Dict[str, Any]:
        """
        Scores two candidates against a job description and computes absolute score differential.
        """
        breakdown_a = CandidateScorer.score(cand_a, job)
        breakdown_b = CandidateScorer.score(cand_b, job)

        score_a = breakdown_a["total"]
        score_b = breakdown_b["total"]
        score_diff = abs(score_a - score_b)

        return {
            "test_type": test_type,
            "candidate_a_id": cand_a.candidate_id,
            "candidate_b_id": cand_b.candidate_id,
            "score_a": score_a,
            "score_b": score_b,
            "score_difference": score_diff,
            "passed": score_diff < 1e-4,
        }

    def run_default_suite(self, job: JobDescription, base_resume_text: str) -> List[Dict[str, Any]]:
        """
        Runs the full default counterfactual audit suite on a given base resume.
        """
        audit_results = []
        for idx, test_case in enumerate(self.DEFAULT_COUNTERFACTUAL_PAIRS, start=1):
            test_type = test_case["test_type"]
            field = test_case["field"]
            val_a = test_case["val_a"]
            val_b = test_case["val_b"]

            if field == "name":
                text_a = f"{val_a}\n" + base_resume_text
                text_b = f"{val_b}\n" + base_resume_text
                c_a = self.process_raw_text(f"AUDIT_{idx}_A", text_a, candidate_name=val_a)
                c_b = self.process_raw_text(f"AUDIT_{idx}_B", text_b, candidate_name=val_b)
            elif field == "email":
                text_a = f"Email: {val_a}\n" + base_resume_text
                text_b = f"Email: {val_b}\n" + base_resume_text
                c_a = self.process_raw_text(f"AUDIT_{idx}_A", text_a)
                c_b = self.process_raw_text(f"AUDIT_{idx}_B", text_b)
            elif field == "pronoun":
                # Varies only the pronoun in an otherwise identical sentence,
                # so this genuinely isolates pronoun influence rather than
                # substituting a whole sentence for a keyword (the previous
                # implementation replaced the substring "managed" with a full
                # sentence, which tested text insertion, not pronoun choice).
                text_a = f"{val_a} led the engineering team and managed project delivery.\n" + base_resume_text
                text_b = f"{val_b} led the engineering team and managed project delivery.\n" + base_resume_text
                c_a = self.process_raw_text(f"AUDIT_{idx}_A", text_a)
                c_b = self.process_raw_text(f"AUDIT_{idx}_B", text_b)
            elif field == "text_padding":
                text_a = val_a + "\n" + base_resume_text
                text_b = val_b + "\n" + base_resume_text
                c_a = self.process_raw_text(f"AUDIT_{idx}_A", text_a)
                c_b = self.process_raw_text(f"AUDIT_{idx}_B", text_b)
            else:
                continue

            result = self.audit_pair(job, test_type, c_a, c_b)
            audit_results.append(result)

        return audit_results
