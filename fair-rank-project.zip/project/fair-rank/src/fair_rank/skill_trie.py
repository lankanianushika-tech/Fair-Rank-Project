from typing import Dict, Optional, Set, List
from .normalizer import TextNormalizer

class TrieNode:
    """
    Node structure for the token-level SkillTrie.
    Children dict maps word tokens to child TrieNodes.
    """
    def __init__(self):
        self.children: Dict[str, TrieNode] = {}
        self.is_end: bool = False
        self.skill_name: Optional[str] = None

class SkillTrie:
    """
    Token-level Prefix Trie data structure for fast dictionary-based skill extraction.
    Supports multiword skills (e.g. "data structures and algorithms") via word-by-word token insertion
    and greedy longest-match sliding window extraction over resume text.
    """

    def __init__(self):
        self.root = TrieNode()
        self.skill_count = 0

    def insert(self, skill: str) -> None:
        """
        Tokenizes the skill phrase into words and inserts word-by-word into the trie.
        Time Complexity: O(length of skill in words)
        """
        if not skill:
            return

        canonical_skill = skill.lower().strip()
        tokens = TextNormalizer.tokenize(canonical_skill)
        if not tokens:
            return

        curr = self.root
        for token in tokens:
            if token not in curr.children:
                curr.children[token] = TrieNode()
            curr = curr.children[token]
        
        if not curr.is_end:
            curr.is_end = True
            curr.skill_name = canonical_skill
            self.skill_count += 1

    def build(self, skills: List[str]) -> None:
        """
        Populates the trie with a list of canonical skills.
        """
        for skill in skills:
            self.insert(skill)

    def extract(self, text: str) -> Set[str]:
        """
        Extracts matched canonical skills from text using a greedy longest-match algorithm.
        Slides across tokenized resume text, matching as far into the trie as possible at each start position.
        Time Complexity: O(L * d) where L = tokens in text, d = maximum trie depth (words per skill).
        """
        matched_skills: Set[str] = set()
        tokens = TextNormalizer.tokenize(text)
        if not tokens:
            return matched_skills

        n = len(tokens)
        i = 0
        while i < n:
            curr = self.root
            longest_match: Optional[str] = None
            longest_match_len = 0

            j = i
            while j < n and tokens[j] in curr.children:
                curr = curr.children[tokens[j]]
                j += 1
                if curr.is_end and curr.skill_name:
                    longest_match = curr.skill_name
                    longest_match_len = j - i

            if longest_match:
                matched_skills.add(longest_match)
                # Advance pointer by the length of the matched phrase
                i += max(1, longest_match_len)
            else:
                i += 1

        return matched_skills
