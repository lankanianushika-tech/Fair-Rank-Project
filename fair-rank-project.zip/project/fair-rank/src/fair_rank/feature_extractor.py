import re
from typing import Tuple, Set

class FeatureExtractor:
    """
    Extracts experience years, education level, and certifications from text using rule-based pattern matching.
    """

    EXP_PATTERNS = [
        re.compile(r'(\d+(?:\.\d+)?)\s*(?:\+\s*)?(?:years?|yrs?)(?:\s+of)?\s+experience', re.IGNORECASE),
        re.compile(r'experience[:\s]*(\d+(?:\.\d+)?)\s*(?:years?|yrs?)', re.IGNORECASE),
    ]

    EDU_HIERARCHY = ["High School", "Associate", "Bachelor", "Master", "Doctorate"]

    CERT_KEYWORDS = [
        "aws certified developer",
        "aws certified solutions architect",
        "certified information systems security professional",
        "cissp",
        "pmp",
        "scrum master",
        "google cloud certified",
        "microsoft certified",
    ]

    @classmethod
    def extract_experience(cls, text: str) -> float:
        for pattern in cls.EXP_PATTERNS:
            match = pattern.search(text)
            if match:
                try:
                    return float(match.group(1))
                except ValueError:
                    pass
        return 0.0

    @classmethod
    def extract_education(cls, text: str) -> str:
        lowercased = text.lower()
        if any(term in lowercased for term in ["ph.d", "phd", "doctorate"]):
            return "Doctorate"
        if any(term in lowercased for term in ["master", "m.s", "ms", "m.sc"]):
            return "Master"
        if any(term in lowercased for term in ["bachelor", "b.s", "bs", "b.sc", "b.a"]):
            return "Bachelor"
        if any(term in lowercased for term in ["associate", "a.s", "a.a"]):
            return "Associate"
        return "High School"

    @classmethod
    def extract_certifications(cls, text: str) -> Set[str]:
        lowercased = text.lower()
        found_certs = set()
        for cert in cls.CERT_KEYWORDS:
            if cert in lowercased:
                found_certs.add(cert)
        return found_certs

    @classmethod
    def extract(cls, text: str) -> Tuple[float, str, Set[str]]:
        exp = cls.extract_experience(text)
        edu = cls.extract_education(text)
        certs = cls.extract_certifications(text)
        return exp, edu, certs
