import heapq
from typing import List, Tuple, Dict
from .candidate import Candidate

class TopKRanker:
    """
    Bounded Min-Heap data structure for efficient Top-K candidate ranking.
    Maintains a heap of max size k containing tuples of (score, tie_breaker, candidate_object).
    
    Time Complexity: O(n log k) for n candidates, compared to O(n log n) for full sorting.
    Space Complexity: O(k).
    """

    def __init__(self, k: int):
        if k <= 0:
            raise ValueError("k must be greater than 0")
        self.k = k
        self.heap: List[Tuple[float, int, Candidate]] = []
        self._counter = 0  # Tie-breaker counter for stable heap ordering

    def push(self, candidate: Candidate, score: float) -> None:
        """
        Pushes a candidate into the min-heap. If heap exceeds size k, evicts the lowest scoring element.
        """
        self._counter += 1
        item = (score, self._counter, candidate)

        if len(self.heap) < self.k:
            heapq.heappush(self.heap, item)
        else:
            if score > self.heap[0][0]:
                heapq.heapreplace(self.heap, item)

    def get_ranked(self) -> List[Candidate]:
        """
        Returns top K candidates sorted in descending order of score.
        """
        sorted_items = sorted(self.heap, key=lambda x: (x[0], x[1]), reverse=True)
        return [item[2] for item in sorted_items]

    def clear(self) -> None:
        self.heap.clear()
        self._counter = 0
