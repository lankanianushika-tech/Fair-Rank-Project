import sys
import os
import time
import tracemalloc
import random
import csv

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from fair_rank.job_description import JobDescription
from fair_rank.candidate import Candidate
from fair_rank.skill_trie import SkillTrie
from fair_rank.skill_graph import SkillGraph
from fair_rank.inverted_index import InvertedIndex
from fair_rank.scorer import CandidateScorer
from fair_rank.top_k_ranker import TopKRanker

def generate_synthetic_candidates(n: int) -> list:
    # NOTE: the original benchmark used a 17-skill pool with candidates drawing
    # 2-6 skills each against a 3-skill job requirement. With that small a pool,
    # InvertedIndex.retrieve() matched almost every candidate (high collision
    # probability), so the "sub-linear filtering" advantage FAIR-RANK is meant
    # to demonstrate never actually triggered -- both approaches ended up
    # scoring ~all N candidates, which is why the original run showed no
    # consistent speedup (see report Section 5/8 correction).
    #
    # This version uses a much larger, more realistic skill vocabulary (60
    # distinct skills) so that a candidate's chance of overlapping with the
    # job's specific required skills is low, giving InvertedIndex.retrieve()
    # a genuinely selective pool to filter down to before scoring.
    skills_pool = [
        "python", "sql", "java", "c++", "c#", "javascript", "typescript", "react",
        "vue", "angular", "node.js", "django", "flask", "spring", "aws", "azure",
        "gcp", "docker", "kubernetes", "terraform", "ansible", "jenkins", "git",
        "data structures", "algorithms", "machine learning", "deep learning",
        "computer vision", "nlp", "rest api", "graphql", "microservices",
        "postgresql", "mysql", "mongodb", "redis", "kafka", "rabbitmq",
        "elasticsearch", "hadoop", "spark", "airflow", "tableau", "power bi",
        "excel", "linux", "bash", "powershell", "ci/cd", "unit testing",
        "agile", "scrum", "project management", "figma", "photoshop",
        "swift", "kotlin", "go", "rust", "php", "ruby"
    ]
    edu_levels = ["Bachelor", "Master", "Doctorate", "Associate"]

    candidates = []
    for i in range(1, n + 1):
        num_skills = random.randint(2, 6)
        cand_skills = set(random.sample(skills_pool, num_skills))
        exp = round(random.uniform(0.5, 10.0), 1)
        edu = random.choice(edu_levels)
        c = Candidate(
            candidate_id=f"SYN_{i:06d}",
            masked_text="Synthetic text profile",
            skills=cand_skills,
            experience_years=exp,
            education_level=edu
        )
        candidates.append(c)
    return candidates

def naive_baseline_screening(candidates: list, job: JobDescription, k: int) -> list:
    scored = []
    for cand in candidates:
        breakdown = CandidateScorer.score(cand, job)
        scored.append((breakdown["total"], cand))
    
    sorted_candidates = sorted(scored, key=lambda x: x[0], reverse=True)
    return [x[1] for x in sorted_candidates[:k]]

def fair_rank_screening(candidates: list, index: InvertedIndex, job: JobDescription, k: int) -> tuple:
    relevant_ids = index.retrieve(job.required_skills, job.preferred_skills)
    if relevant_ids:
        pool = [c for c in candidates if c.candidate_id in relevant_ids]
    else:
        pool = candidates

    ranker = TopKRanker(k)
    for cand in pool:
        breakdown = CandidateScorer.score(cand, job)
        ranker.push(cand, breakdown["total"])

    return ranker.get_ranked(), len(pool)

def run_benchmark():
    population_sizes = [100, 500, 1000, 5000, 10000]
    k = 10
    
    job = JobDescription(
        title="Benchmark Senior Dev",
        required_skills={"python", "sql", "data structures"},
        preferred_skills={"aws", "docker"},
        min_experience_years=3.0,
        k=k
    )

    results = []

    print(f"{'N Candidates':<15} | {'Pool (Filtered)':<16} | {'FAIR-RANK Time (s)':<20} | {'Naive Time (s)':<18} | {'Speedup':<10}")
    print("-" * 92)

    # Run each population size multiple times and average, since single-run
    # timings at small N are noisy enough (sub-millisecond) to flip the
    # speedup ratio below 1.0x purely from measurement noise.
    repeats = 5

    for n in population_sizes:
        fr_times, nv_times, pool_sizes = [], [], []
        mem_fair_rank = mem_naive = 0

        for r in range(repeats):
            candidates = generate_synthetic_candidates(n)

            index = InvertedIndex()
            for c in candidates:
                index.add(c)

            tracemalloc.start()
            t0 = time.perf_counter()
            _, pool_size = fair_rank_screening(candidates, index, job, k)
            fr_times.append(time.perf_counter() - t0)
            _, mem_fair_rank = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            pool_sizes.append(pool_size)

            tracemalloc.start()
            t0 = time.perf_counter()
            _ = naive_baseline_screening(candidates, job, k)
            nv_times.append(time.perf_counter() - t0)
            _, mem_naive = tracemalloc.get_traced_memory()
            tracemalloc.stop()

        t_fair_rank = sum(fr_times) / repeats
        t_naive = sum(nv_times) / repeats
        avg_pool = sum(pool_sizes) / repeats
        speedup = t_naive / max(t_fair_rank, 1e-6)

        print(f"{n:<15} | {avg_pool:<16.0f} | {t_fair_rank:<20.5f} | {t_naive:<18.5f} | {speedup:<10.2f}x")

        results.append({
            "n_candidates": n,
            "k": k,
            "avg_filtered_pool_size": round(avg_pool, 1),
            "fair_rank_time_sec": round(t_fair_rank, 6),
            "naive_time_sec": round(t_naive, 6),
            "speedup": round(speedup, 2),
            "fair_rank_mem_mb": round(mem_fair_rank / (1024 * 1024), 4),
            "naive_mem_mb": round(mem_naive / (1024 * 1024), 4)
        })

    # Save to CSV using standard library csv.
    # Use a path relative to this file (not the caller's cwd) so this still
    # works correctly when imported and run from the notebook, whose working
    # directory is notebooks/, not the project root.
    results_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
    os.makedirs(results_dir, exist_ok=True)
    csv_path = os.path.join(results_dir, "efficiency_results.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        fieldnames = ["n_candidates", "k", "avg_filtered_pool_size", "fair_rank_time_sec", "naive_time_sec", "speedup", "fair_rank_mem_mb", "naive_mem_mb"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)
    print(f"\n[+] Results saved to {csv_path}")

    # Generate Plot if matplotlib is installed
    try:
        import matplotlib.pyplot as plt
        plt.figure(figsize=(10, 6))
        ns = [r["n_candidates"] for r in results]
        t_fr = [r["fair_rank_time_sec"] for r in results]
        t_nv = [r["naive_time_sec"] for r in results]
        plt.plot(ns, t_fr, marker='o', label='FAIR-RANK O(N log k)', linewidth=2.5, color='#1f77b4')
        plt.plot(ns, t_nv, marker='s', linestyle='--', label='Naive Baseline O(N log N)', linewidth=2.5, color='#d62728')
        plt.title('Execution Time Scaling: FAIR-RANK vs Naive Sorting Baseline', fontsize=14, fontweight='bold')
        plt.xlabel('Number of Candidates (N)', fontsize=12)
        plt.ylabel('Wall-Clock Execution Time (seconds)', fontsize=12)
        plt.grid(True, linestyle=':', alpha=0.6)
        plt.legend(fontsize=12)
        plt.tight_layout()
        plot_path = os.path.join(results_dir, "efficiency_plot.png")
        plt.savefig(plot_path, dpi=300)
        plt.close()
        print(f"[+] Empirical scaling plot saved to {plot_path}")
    except ImportError:
        print("[!] Matplotlib not available in current environment; CSV saved successfully.")

if __name__ == "__main__":
    run_benchmark()
