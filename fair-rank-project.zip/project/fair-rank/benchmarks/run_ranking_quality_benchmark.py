import sys
import os
import csv

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from fair_rank.job_description import JobDescription
from fair_rank.candidate import Candidate
from fair_rank.scorer import CandidateScorer
from fair_rank.top_k_ranker import TopKRanker

def run_quality_benchmark():
    job = JobDescription(
        title="Senior Python Backend Developer",
        required_skills={"python", "sql", "data structures"},
        preferred_skills={"aws", "docker"},
        min_experience_years=4.0,
        k=5
    )

    test_candidates = [
        (Candidate("C1", "", skills={"python", "sql", "data structures", "aws"}, experience_years=5.0), True),
        (Candidate("C2", "", skills={"python", "sql", "data structures"}, experience_years=4.0), True),
        (Candidate("C3", "", skills={"python", "sql"}, experience_years=3.0), False),
        (Candidate("C4", "", skills={"java", "c++"}, experience_years=6.0), False),
        (Candidate("C5", "", skills={"python", "data structures", "docker"}, experience_years=4.5), True),
        (Candidate("C6", "", skills={"javascript", "react"}, experience_years=2.0), False),
        (Candidate("C7", "", skills={"python", "sql", "data structures", "docker", "aws"}, experience_years=6.0), True),
        (Candidate("C8", "", skills={"html", "css"}, experience_years=1.0), False),
    ]

    total_relevant_in_population = sum(1 for _, is_rel in test_candidates if is_rel)

    ranker = TopKRanker(k=job.k)
    for cand, _ in test_candidates:
        breakdown = CandidateScorer.score(cand, job)
        ranker.push(cand, breakdown["total"])

    shortlist = ranker.get_ranked()
    shortlist_ids = {c.candidate_id for c in shortlist}

    relevant_in_shortlist = sum(
        1 for cand, is_rel in test_candidates
        if is_rel and cand.candidate_id in shortlist_ids
    )

    precision_at_k = relevant_in_shortlist / len(shortlist) if shortlist else 0.0
    recall_at_k = relevant_in_shortlist / total_relevant_in_population if total_relevant_in_population > 0 else 0.0

    print("=" * 60)
    print(f"RANKING QUALITY BENCHMARK (k = {job.k})")
    print("=" * 60)
    print(f"Total Relevant Candidates in Population: {total_relevant_in_population}")
    print(f"Relevant Candidates Retrieved in Shortlist: {relevant_in_shortlist}")
    print(f"Precision@{job.k}: {precision_at_k:.4f} ({precision_at_k * 100:.1f}%)")
    print(f"Recall@{job.k}:    {recall_at_k:.4f} ({recall_at_k * 100:.1f}%)")

    # Path relative to this file, not the caller's cwd, so this also works
    # correctly when imported and run from the notebook (cwd = notebooks/).
    results_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
    os.makedirs(results_dir, exist_ok=True)
    csv_path = os.path.join(results_dir, "ranking_quality_results.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["k", "total_relevant_population", "relevant_retrieved", "precision_at_k", "recall_at_k"])
        writer.writerow([job.k, total_relevant_in_population, relevant_in_shortlist, round(precision_at_k, 4), round(recall_at_k, 4)])

    print(f"\n[+] Quality benchmark metrics saved to {csv_path}")

if __name__ == "__main__":
    run_quality_benchmark()
