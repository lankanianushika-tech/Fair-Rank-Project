import pytest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from fair_rank.skill_graph import SkillGraph

def test_direct_synonym_resolution():
    synonym_data = {
        "py": ["python"],
        "js": ["javascript"],
        "k8s": ["kubernetes"]
    }
    graph = SkillGraph(synonym_data)
    resolved = graph.resolve_synonyms({"py", "js", "docker"})
    assert "python" in resolved
    assert "javascript" in resolved
    assert "docker" in resolved

def test_unknown_term_preservation():
    graph = SkillGraph({})
    resolved = graph.resolve_synonyms({"unique_skill"})
    assert resolved == {"unique_skill"}

def test_no_multi_hop_expansion():
    # If A maps to B and B maps to C, resolution of A should strictly yield {A, B}, not C.
    synonym_data = {
        "term_a": ["term_b"],
        "term_b": ["term_c"]
    }
    graph = SkillGraph(synonym_data)
    resolved = graph.resolve_synonyms({"term_a"})
    assert "term_b" in resolved
    assert "term_c" not in resolved
