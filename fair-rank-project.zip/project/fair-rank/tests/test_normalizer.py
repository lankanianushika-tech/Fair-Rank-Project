import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from fair_rank.normalizer import TextNormalizer


def test_lowercases_and_strips_sentence_punctuation():
    text = "Experienced Engineer proficient in Python, SQL, and REST API."
    normalized = TextNormalizer.normalize(text)
    assert normalized == "experienced engineer proficient in python sql and rest api"


def test_preserves_tech_tokens_with_special_characters():
    text = "Skilled in C++, C#, .NET, Node.js, and CI/CD pipelines"
    normalized = TextNormalizer.normalize(text)
    assert "c++" in normalized
    assert "c#" in normalized
    assert ".net" in normalized
    assert "node.js" in normalized
    assert "ci/cd" in normalized


def test_collapses_repeated_whitespace():
    text = "Software   Engineer    with   Python   experience"
    normalized = TextNormalizer.normalize(text)
    assert "  " not in normalized
    assert normalized == "software engineer with python experience"


def test_empty_text_returns_empty_string():
    assert TextNormalizer.normalize("") == ""
    assert TextNormalizer.normalize(None) == ""


def test_tokenize_splits_normalized_text_into_words():
    tokens = TextNormalizer.tokenize("Python, SQL, and Data Structures.")
    assert tokens == ["python", "sql", "and", "data", "structures"]


def test_tokenize_empty_text_returns_empty_list():
    assert TextNormalizer.tokenize("") == []
