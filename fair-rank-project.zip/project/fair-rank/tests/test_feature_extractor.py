import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from fair_rank.feature_extractor import FeatureExtractor


def test_extract_experience_years_common_phrasing():
    assert FeatureExtractor.extract_experience("5 years of experience in backend development") == 5.0
    assert FeatureExtractor.extract_experience("Experience: 3 years") == 3.0
    assert FeatureExtractor.extract_experience("no numeric experience mentioned here") == 0.0


def test_extract_education_hierarchy_precedence():
    # Doctorate should win even if "bachelor" also appears earlier in the text
    text = "Holds a Bachelor's degree, later completed a PhD in Computer Science"
    assert FeatureExtractor.extract_education(text) == "Doctorate"
    assert FeatureExtractor.extract_education("Master of Science graduate") == "Master"
    assert FeatureExtractor.extract_education("Bachelor of Engineering") == "Bachelor"
    assert FeatureExtractor.extract_education("Associate degree holder") == "Associate"
    assert FeatureExtractor.extract_education("no qualification text present") == "High School"


def test_extract_certifications_matches_known_keywords():
    text = "Holds AWS Certified Developer and PMP certifications"
    certs = FeatureExtractor.extract_certifications(text)
    assert "aws certified developer" in certs
    assert "pmp" in certs
    assert len(certs) == 2


def test_extract_certifications_no_match_returns_empty_set():
    assert FeatureExtractor.extract_certifications("no relevant credentials listed") == set()


def test_extract_combines_all_three_components():
    text = "5 years of experience. Master of Science. AWS Certified Developer."
    exp, edu, certs = FeatureExtractor.extract(text)
    assert exp == 5.0
    assert edu == "Master"
    assert "aws certified developer" in certs
