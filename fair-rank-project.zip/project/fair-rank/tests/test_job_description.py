import pytest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from fair_rank.job_description import JobDescription


def test_default_weights_sum_to_one():
    job = JobDescription("Backend Developer", required_skills={"python", "sql"})
    assert abs(sum(job.weights.values()) - 1.0) < 1e-9
    assert job.weights == JobDescription.DEFAULT_WEIGHTS


def test_custom_weights_that_sum_to_one_are_accepted():
    custom = {"required_skills": 0.6, "preferred_skills": 0.1, "experience": 0.1, "education": 0.1, "certifications": 0.1}
    job = JobDescription("Backend Developer", required_skills={"python"}, weights=custom)
    assert job.weights == custom


def test_invalid_weights_raise_value_error():
    bad = {"required_skills": 0.9, "preferred_skills": 0.2, "experience": 0.15, "education": 0.10, "certifications": 0.05}
    with pytest.raises(ValueError):
        JobDescription("Backend Developer", required_skills={"python"}, weights=bad)


def test_skills_are_lowercased_and_stripped():
    job = JobDescription("Backend Developer", required_skills={" Python ", "SQL"}, preferred_skills={"AWS "})
    assert job.required_skills == {"python", "sql"}
    assert job.preferred_skills == {"aws"}


def test_empty_optional_sets_default_correctly():
    job = JobDescription("Backend Developer", required_skills={"python"})
    assert job.preferred_skills == set()
    assert job.required_certifications == set()
    assert job.k == 10
    assert job.required_education == "Bachelor"
