import pytest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from fair_rank.skill_trie import SkillTrie

def test_single_word_match():
    trie = SkillTrie()
    trie.build(["python", "java", "sql"])
    matches = trie.extract("Experienced in python and SQL programming.")
    assert matches == {"python", "sql"}

def test_multiword_match():
    trie = SkillTrie()
    trie.build(["data structures", "algorithms", "data science"])
    matches = trie.extract("Expert in data structures and algorithms with background in data science.")
    assert "data structures" in matches
    assert "algorithms" in matches
    assert "data science" in matches

def test_no_match_edge_case():
    trie = SkillTrie()
    trie.build(["python", "java"])
    matches = trie.extract("Sales representative with experience in customer relations.")
    assert matches == set()

def test_overlapping_prefix_matching():
    trie = SkillTrie()
    trie.build(["data", "data structures", "data structures and algorithms"])
    matches = trie.extract("I study data structures and algorithms daily.")
    # Greedy longest match should pick "data structures and algorithms"
    assert "data structures and algorithms" in matches
