import pytest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from fair_rank.top_k_ranker import TopKRanker
from fair_rank.candidate import Candidate

def test_top_k_eviction():
    ranker = TopKRanker(k=3)
    c1 = Candidate("C1", "")
    c2 = Candidate("C2", "")
    c3 = Candidate("C3", "")
    c4 = Candidate("C4", "")
    c5 = Candidate("C5", "")

    ranker.push(c1, 0.50)
    ranker.push(c2, 0.90)
    ranker.push(c3, 0.30)
    ranker.push(c4, 0.80)
    ranker.push(c5, 0.95)

    ranked = ranker.get_ranked()
    assert len(ranked) == 3
    # Top 3 should be C5 (0.95), C2 (0.90), C4 (0.80)
    ranked_ids = [c.candidate_id for c in ranked]
    assert ranked_ids == ["C5", "C2", "C4"]

def test_k_larger_than_population():
    ranker = TopKRanker(k=10)
    c1 = Candidate("C1", "")
    c2 = Candidate("C2", "")
    ranker.push(c1, 0.6)
    ranker.push(c2, 0.8)
    ranked = ranker.get_ranked()
    assert len(ranked) == 2
    assert ranked[0].candidate_id == "C2"
