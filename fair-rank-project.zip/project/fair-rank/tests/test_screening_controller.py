import pytest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from fair_rank.screening_controller import ScreeningController
from fair_rank.job_description import JobDescription

def test_screening_controller_end_to_end():
    dict_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../data/skills_dictionary.json'))
    syn_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../data/skills_synonyms.json'))

    controller = ScreeningController(dict_path, syn_path)
    job = JobDescription("Senior Software Engineer", required_skills={"python", "sql"}, k=3)

    sample_resumes = [
        {"candidate_id": "C01", "full_name": "Alice", "resume_text": "Experienced Python and SQL developer with 5 years experience.", "experience_years": 5},
        {"candidate_id": "C02", "full_name": "Bob", "resume_text": "Java and C++ engineer with 2 years experience.", "experience_years": 2},
        {"candidate_id": "C03", "full_name": "Charlie", "resume_text": "Python engineer proficient in rest api and sql with 4 years experience.", "experience_years": 4},
    ]

    shortlist, audit = controller.run_screening(job, sample_resumes)
    assert len(shortlist) <= 3
    assert shortlist[0].candidate_id in ["C01", "C03"]
    assert len(audit) > 0
