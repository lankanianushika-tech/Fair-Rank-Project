import pytest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from fair_rank.inverted_index import InvertedIndex
from fair_rank.candidate import Candidate

def test_inverted_index_add_and_retrieve():
    index = InvertedIndex()
    c1 = Candidate("C001", "text", skills={"python", "sql"})
    c2 = Candidate("C002", "text", skills={"java", "sql"})
    c3 = Candidate("C003", "text", skills={"react"})

    index.add(c1)
    index.add(c2)
    index.add(c3)

    retrieved_python = index.retrieve(["python"])
    assert retrieved_python == {"C001"}

    retrieved_sql = index.retrieve(["sql"])
    assert retrieved_sql == {"C001", "C002"}

    retrieved_combined = index.retrieve(["python"], ["react"])
    assert retrieved_combined == {"C001", "C03"} or "C003" in retrieved_combined

def test_empty_query():
    index = InvertedIndex()
    retrieved = index.retrieve([], [])
    assert retrieved == set()
