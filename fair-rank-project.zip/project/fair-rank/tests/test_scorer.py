import pytest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from fair_rank.job_description import JobDescription
from fair_rank.candidate import Candidate
from fair_rank.scorer import CandidateScorer

def test_scorer_exact_computation():
    job = JobDescription(
        title="Backend Dev",
        required_skills={"python", "sql"},
        preferred_skills={"aws"},
        min_experience_years=4.0,
        required_education="Bachelor",
        required_certifications={"aws certified developer"},
        weights={
            "required_skills": 0.50,
            "preferred_skills": 0.20,
            "experience": 0.15,
            "education": 0.10,
            "certifications": 0.05,
        }
    )

    # Perfect matching candidate
    c_perfect = Candidate(
        candidate_id="C_PERFECT",
        masked_text="",
        skills={"python", "sql", "aws"},
        experience_years=4.0,
        education_level="Bachelor",
        certifications={"aws certified developer"}
    )
    b_perfect = CandidateScorer.score(c_perfect, job)
    assert abs(b_perfect["total"] - 1.0) < 1e-5

    # Partial matching candidate
    c_partial = Candidate(
        candidate_id="C_PARTIAL",
        masked_text="",
        skills={"python"},  # 1/2 required skills = 0.50 score -> 0.50*0.50 = 0.25
        experience_years=2.0,  # 2/4 experience = 0.50 score -> 0.50*0.15 = 0.075
        education_level="Bachelor",  # 1.0 -> 0.10
        certifications=set()  # 0 -> 0
    )
    b_partial = CandidateScorer.score(c_partial, job)
    expected_total = (0.5 * 0.50) + (0.0 * 0.20) + (0.5 * 0.15) + (1.0 * 0.10) + (0.0 * 0.05)
    assert abs(b_partial["total"] - expected_total) < 1e-5
