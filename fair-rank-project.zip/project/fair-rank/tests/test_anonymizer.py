import pytest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from fair_rank.anonymizer import ResumeAnonymizer

def test_pii_masking():
    raw_text = "Contact Alice Smith at alice@example.com or +1-555-0199. Born 12/05/1990. Skilled in Python."
    masked = ResumeAnonymizer.mask(raw_text, name="Alice Smith")

    assert "[NAME]" in masked
    assert "Alice" not in masked
    assert "[EMAIL]" in masked
    assert "alice@example.com" not in masked
    assert "[PHONE]" in masked
    assert "+1-555-0199" not in masked
    assert "[DOB]" in masked
    assert "Python" in masked
