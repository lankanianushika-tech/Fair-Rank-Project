import pytest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from fair_rank.skill_trie import SkillTrie
from fair_rank.skill_graph import SkillGraph
from fair_rank.fairness_auditor import FairnessAuditor
from fair_rank.job_description import JobDescription

def test_counterfactual_name_fairness():
    trie = SkillTrie()
    trie.build(["python", "sql", "data structures"])
    graph = SkillGraph({})
    auditor = FairnessAuditor(trie, graph)

    job = JobDescription("Backend Developer", required_skills={"python", "sql"})
    
    # Test name counterfactual pair
    c_a = auditor.process_raw_text("A", "John Smith\nProficient in Python and SQL.", candidate_name="John Smith")
    c_b = auditor.process_raw_text("B", "Mary Smith\nProficient in Python and SQL.", candidate_name="Mary Smith")

    result = auditor.audit_pair(job, "Name Bias Test", c_a, c_b)
    assert result["passed"] is True
    assert result["score_difference"] < 1e-4


def test_default_suite_pronoun_case_actually_varies_pronoun():
    """
    Regression test: the 'Pronoun Bias' counterfactual case must vary only the
    pronoun ('He' vs 'She') between two otherwise-identical sentences, not
    substitute an entire sentence for a keyword. This also confirms that
    score parity holds under a genuine pronoun swap, not just a name swap.
    """
    trie = SkillTrie()
    trie.build(["python", "sql", "data structures"])
    graph = SkillGraph({})
    auditor = FairnessAuditor(trie, graph)
    job = JobDescription("Backend Developer", required_skills={"python", "sql"})

    pronoun_case = next(
        c for c in FairnessAuditor.DEFAULT_COUNTERFACTUAL_PAIRS
        if c["test_type"] == "Pronoun Bias"
    )
    assert pronoun_case["field"] == "pronoun"
    assert pronoun_case["val_a"] in ("He", "She")
    assert pronoun_case["val_b"] in ("He", "She")
    assert pronoun_case["val_a"] != pronoun_case["val_b"]

    results = auditor.run_default_suite(job, "Proficient in Python and SQL.")
    pronoun_result = next(r for r in results if r["test_type"] == "Pronoun Bias")
    assert pronoun_result["passed"] is True
    assert pronoun_result["score_difference"] < 1e-4
