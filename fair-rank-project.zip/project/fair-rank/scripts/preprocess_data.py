"""
Data preprocessing script for FAIR-RANK.

Produces data/processed/resumes_clean.csv from data/raw/resumes_raw.csv.

Previously this project's "processed" file was a byte-for-byte duplicate of
the raw file -- this script actually performs the cleaning step it is
labelled as doing:

  1. Trims stray whitespace on every field.
  2. Fills missing/blank `certifications` with the literal string "None"
     instead of leaving an ambiguous empty cell.
  3. Standardises phone number formatting to a single `+<country>-<digits>`
     pattern.
  4. Lowercases email addresses (emails are case-insensitive; raw data
     entry sometimes mixes case).
  5. Adds a `normalized_resume_text` column produced by
     `TextNormalizer.normalize()` -- lowercased, punctuation-stripped,
     tech-token-preserving text -- so the pipeline's SkillTrie/SkillGraph
     stages can be fed pre-normalized text directly.

Note on identity masking: full PII masking (name/email/phone/DOB) is
deliberately NOT baked into this file. `ResumeAnonymizer.mask()` needs the
candidate's `full_name` to redact name occurrences, and the notebook /
ScreeningController apply it at pipeline run-time (see notebook Cell 6 and
ScreeningController.run()). Baking masked text into the "clean" CSV would
also destroy the ability to demonstrate the anonymizer's before/after
behaviour in the notebook. This script performs genuine field-level
cleaning; identity masking remains a pipeline stage, as designed.

Usage:
    python3 scripts/preprocess_data.py
"""
import csv
import os
import re
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))
from fair_rank.normalizer import TextNormalizer  # noqa: E402

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RAW_PATH = os.path.join(BASE_DIR, "data", "raw", "resumes_raw.csv")
CLEAN_PATH = os.path.join(BASE_DIR, "data", "processed", "resumes_clean.csv")

PHONE_DIGITS_PATTERN = re.compile(r"\D")


def clean_phone(raw_phone: str) -> str:
    if not raw_phone or not raw_phone.strip():
        return ""
    digits = PHONE_DIGITS_PATTERN.sub("", raw_phone)
    if len(digits) >= 10:
        country = digits[:-10] or "1"
        local = digits[-10:]
        return f"+{country}-{local[:3]}-{local[3:6]}-{local[6:]}"
    return raw_phone.strip()


def main():
    with open(RAW_PATH, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = list(reader.fieldnames) + ["normalized_resume_text"]
        rows = list(reader)

    cleaned_rows = []
    for row in rows:
        cleaned = {k: (v.strip() if isinstance(v, str) else v) for k, v in row.items()}
        cleaned["certifications"] = cleaned.get("certifications") or "None"
        cleaned["phone"] = clean_phone(cleaned.get("phone", ""))
        cleaned["email"] = cleaned.get("email", "").lower()
        cleaned["normalized_resume_text"] = TextNormalizer.normalize(cleaned.get("resume_text", ""))
        cleaned_rows.append(cleaned)

    os.makedirs(os.path.dirname(CLEAN_PATH), exist_ok=True)
    with open(CLEAN_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(cleaned_rows)

    print(f"[+] Wrote {len(cleaned_rows)} cleaned rows to {CLEAN_PATH}")


if __name__ == "__main__":
    main()
